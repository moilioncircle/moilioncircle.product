package com.moilioncircle.weixin.oauth;

import org.pac4j.core.context.WebContext;
import org.pac4j.oauth.client.BaseOAuth20Client;
import org.pac4j.oauth.profile.JsonHelper;
import org.pac4j.oauth.profile.OAuthAttributesDefinition;
import org.scribe.model.Token;

import com.fasterxml.jackson.databind.JsonNode;

/**
 * Created by trydofor on 9/29/15.
 */
public class WeixinClient extends BaseOAuth20Client<WeixinProfile> {


    // https://open.weixin.qq.com/cgi-bin/showdocument?action=dir_list&t=resource/res_list&verify=1&id=open1419316505&token=&lang=zh_CN

    private final String appid; // appid	是	应用唯一标识，在微信开放平台提交应用审核通过后获得
    private final String secret; // 应用密钥AppSecret，在微信开放平台提交应用审核通过后获得
    private static final String USERINFO_URL = "https://api.weixin.qq.com/sns/userinfo?access_token=%s&openid=%s";
    private static final OAuthAttributesDefinition WEIXINDEFINITION = new WeixinAttributesDefinition();

    public WeixinClient(String appid, String secret) {
        this.appid = appid;
        this.secret = secret;
        setKey(appid);
        setSecret(secret);
    }

    @Override
    protected WeixinClient newClient() {
        final WeixinClient newClient = new WeixinClient(appid, secret);
        return newClient;
    }

    @Override
    protected void internalInit() {
        super.internalInit();
        this.service = new WeixinOauth20ServiceImpl(appid, secret, this.callbackUrl);
    }


    @Override
    protected String getProfileUrl(final Token accessToken) {
        return String.format(USERINFO_URL, accessToken.getToken(), accessToken.getSecret());
    }

    @Override
    protected WeixinProfile extractUserProfile(final String body) {
        final WeixinProfile profile = new WeixinProfile();
        final JsonNode json = JsonHelper.getFirstNode(body);
        if (json != null) {
            for (final String attribute : WEIXINDEFINITION.getPrincipalAttributes()) {
                profile.addAttribute(attribute, JsonHelper.get(json, attribute));
            }
        }
        return profile;
    }

    @Override
    protected boolean requiresStateParameter() {
        return true;
    }


    @Override
    protected boolean hasBeenCancelled(WebContext context) {
        return false;
    }
}
