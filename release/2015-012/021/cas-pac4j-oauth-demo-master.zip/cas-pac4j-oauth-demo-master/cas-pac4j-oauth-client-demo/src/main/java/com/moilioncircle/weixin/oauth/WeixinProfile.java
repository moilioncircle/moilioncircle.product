package com.moilioncircle.weixin.oauth;

import java.util.List;

import org.pac4j.core.profile.AttributesDefinition;
import org.pac4j.oauth.profile.OAuth20Profile;

/**
 * Created by trydofor on 9/29/15.
 */
public class WeixinProfile extends OAuth20Profile {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final WeixinAttributesDefinition ATTRIBUTES_DEFINITION = new WeixinAttributesDefinition();

    @Override
    protected AttributesDefinition getAttributesDefinition() {
        return ATTRIBUTES_DEFINITION;
    }

    @Override
    public String getFamilyName() {
        return (String) getAttribute(WeixinAttributesDefinition.NICKNAME);
    }

    @Override
    public String getDisplayName() {
        return (String) getAttribute(WeixinAttributesDefinition.NICKNAME);
    }

    @Override
    public String getPictureUrl() {
        return (String) getAttribute(WeixinAttributesDefinition.HEADIMGURL);
    }

    public String getOpenid(){
        return (String) getAttribute(WeixinAttributesDefinition.OPENID);
    }

    public String getNickname(){
        return (String) getAttribute(WeixinAttributesDefinition.NICKNAME);
    }

    public Integer getSex(){
        return (Integer) getAttribute(WeixinAttributesDefinition.SEX);
    }

    public String getProvince(){
        return (String) getAttribute(WeixinAttributesDefinition.PROVINCE);
    }

    public String getCity(){
        return (String) getAttribute(WeixinAttributesDefinition.CITY);
    }

    public String getCountry(){
        return (String) getAttribute(WeixinAttributesDefinition.COUNTRY);
    }

    public String getHeadimgurl(){
        return (String) getAttribute(WeixinAttributesDefinition.HEADIMGURL);
    }

    @SuppressWarnings("unchecked")
	public List<String> getPrivilege(){
        return (List<String>) getAttribute(WeixinAttributesDefinition.PRIVILEGE);
    }

    public String getUnionid(){
        return (String) getAttribute(WeixinAttributesDefinition.UNIONID);
    }
}
