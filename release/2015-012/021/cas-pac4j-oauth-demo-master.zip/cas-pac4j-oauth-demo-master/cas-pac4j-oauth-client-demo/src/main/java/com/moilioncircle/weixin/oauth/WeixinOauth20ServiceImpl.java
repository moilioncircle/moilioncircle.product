package com.moilioncircle.weixin.oauth;

import com.fasterxml.jackson.databind.JsonNode;
import org.pac4j.oauth.profile.JsonHelper;
import org.scribe.exceptions.OAuthException;
import org.scribe.model.*;
import org.scribe.oauth.OAuthService;
import org.scribe.oauth.StateOAuth20Service;
import org.scribe.utils.OAuthEncoder;
import org.scribe.utils.Preconditions;

/**
 * Created by trydofor on 9/30/15.
 */
public class WeixinOauth20ServiceImpl implements OAuthService, StateOAuth20Service {

    private static final String LOGIN_URL = "https://open.weixin.qq.com/connect/qrconnect?appid=%s&redirect_uri=%s&response_type=code&scope=snsapi_login&state=%s#wechat_redirect";
    private static final String ACCESSTOKEN_URL = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=%s&secret=%s&code=%s&grant_type=authorization_code";

    private final String appid;
    private final String secret;
    private final String callbackUrl;

    public WeixinOauth20ServiceImpl(String appid, String secret, String callbackUrl) {
        this.appid = appid;
        this.secret = secret;
        this.callbackUrl = OAuthEncoder.encode(callbackUrl);

    }

    public Token getAccessToken(Token requestToken, Verifier verifier) {
        String accesstokenUrl = String.format(ACCESSTOKEN_URL, appid, secret, verifier.getValue());
        OAuthRequest request = new OAuthRequest(Verb.GET, accesstokenUrl);

        Response response = request.send();
        return extract(response.getBody());
    }

    public Token extract(final String response) {
        Preconditions.checkEmptyString(response, "Cannot extract a token from a null or empty String");
        final JsonNode json = JsonHelper.getFirstNode(response);
        try {
            String accessToken = json.get("access_token").asText();
            String openId = json.get("openid").asText();
            return new Token(accessToken, openId);
        } catch (Exception e) {
            throw new OAuthException("Cannot extract an acces token. Response was: " + response, e);
        }

    }

    public Token getRequestToken() {
        throw new UnsupportedOperationException("Unsupported operation, please use \'getAuthorizationUrl\' and redirect your users there");
    }

    public String getVersion() {
        return "2.0";
    }

    public void signRequest(Token accessToken, OAuthRequest request) {
        request.addQuerystringParameter("access_token", accessToken.getToken());
    }

    public String getAuthorizationUrl(Token requestToken) {
        return String.format(LOGIN_URL, appid, callbackUrl);
    }

    @Override
    public String getAuthorizationUrl(String state) {
        return String.format(LOGIN_URL, appid, callbackUrl, state);
    }
}
